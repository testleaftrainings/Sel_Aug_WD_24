package com.leaftaps.testcase;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.ProjectSpecificMethods;
import com.leaftaps.pages.LoginPage;

public class TC_001_Login extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setValues() {
		testcaseName="LoginPage";
		testDescription="Leaftaps Applications";
		authors="Dilip";
		category="smoke";
		excelFileName="Login";
	}
	
	
	
	@Test(dataProvider = "fetchData")
	public void runLogin(String uName,String pass) {
		LoginPage lp=new LoginPage();
		lp.enteruserName(uName).password(pass).clickLoginButton();
		
	}

}
