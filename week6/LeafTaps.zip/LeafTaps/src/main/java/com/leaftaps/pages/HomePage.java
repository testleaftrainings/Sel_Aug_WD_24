package com.leaftaps.pages;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods {

	public MyHomePage clickOnCrmsfa() {
		click(Locators.PARTIAL_LINKTEXT, "CRM");
		reportStep("CRMSFA clicked Successful", "pass");
return new MyHomePage();
	}
	
	
	public LoginPage clickOnLogoutButton() {
		click(Locators.XPATH, "//input[@class='decorativeSubmit']");
		reportStep("Logout button clicked", "pass");
		return new LoginPage();
	}
}
