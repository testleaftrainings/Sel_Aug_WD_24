package com.leaftaps.pages;

import org.openqa.selenium.WebElement;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {
	
	
	public LoginPage enteruserName(String name) {
		
		WebElement userN = locateElement("username");
		type(userN, name);
		reportStep("Username Enter Successful", "pass");
		return this;
	}
	
	
	public LoginPage password(String pass) {

		type(locateElement("password"),pass);
		reportStep("Password enter successful", "pass");
		return this;

	}

	public HomePage clickLoginButton() {
		click(Locators.CLASS_NAME, "decorativeSubmit");
		reportStep("Login is Successful", "pass");
		return new HomePage();

	}
	
}
