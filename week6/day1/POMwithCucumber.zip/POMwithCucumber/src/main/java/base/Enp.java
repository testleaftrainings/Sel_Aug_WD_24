package base;

public class Enp {
	public static void main(String[] args) {
		
Encapsulation e=new Encapsulation();
e.setName("dilip");
System.out.println(e.getName());
	}

}
