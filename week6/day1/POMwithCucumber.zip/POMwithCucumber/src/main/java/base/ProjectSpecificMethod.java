 package base;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.IntegrationWithTC;



public class ProjectSpecificMethod extends AbstractTestNGCucumberTests{


	
	private static final ThreadLocal<RemoteWebDriver> cdDriver=new ThreadLocal<RemoteWebDriver>();
	
	public void setDriver() {
		cdDriver.set(new ChromeDriver());
	}
	
	
	public RemoteWebDriver getDriver() {
		return cdDriver.get();
	}
	public static Properties p;
	
	public String data;
	
	
	@BeforeMethod
	public void preCondition(String fileName) throws IOException {
		
		FileInputStream f=new FileInputStream("src/main/resources/English.properties");
		
		p=new Properties();
		
		p.load(f);

	 setDriver();
	 getDriver().manage().window().maximize();
	 getDriver().get("http://leaftaps.com/opentaps/control/main");
	 getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
	}
	
	
	
	@AfterMethod
	public void postCondition() {
		getDriver().close();
	}
	

	@DataProvider(name="getData",indices = {0})
	public String[][] setValue() throws IOException{
		//excel prg Classname.methodname and return value
		return IntegrationWithTC.readExcel(data);
		
	}
}
