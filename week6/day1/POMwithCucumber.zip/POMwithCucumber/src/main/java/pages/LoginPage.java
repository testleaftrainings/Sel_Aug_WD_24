package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginPage extends ProjectSpecificMethod {
	
	

	
	@When("Enter the username as DemoCsr")
	public LoginPage enterUserName() {
		getDriver().findElement(By.id("username")).sendKeys(p.getProperty("userName"));
		
		return this;
	}

	@And("Enter the passWord as crmsfa")
	public LoginPage enterPassWord() {
		getDriver().findElement(By.id("password")).sendKeys(p.getProperty("password"));
		
		return this;
	}
	
	@And("Click on Login Button")
	public HomePage clickOnLoginButton() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		return new HomePage();
	}
	
	@Then("Verfiy the login is Successful")
	public void verify() {
		String title = getDriver().getTitle();
		
		if(title.contains("Leaftaps")) {
			System.out.println("Login is successful");
		}else {
			System.out.println("Login is not successful");
		}
	}
}
