package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class MyHomePage extends ProjectSpecificMethod {

	
	
	
	public CreateLeadPage clickOnLeads() {
		getDriver().findElement(By.linkText(p.getProperty("MyHomePage.Leads"))).click();
		
		return new CreateLeadPage();
	}
	
	
	public void clickOnContacts() {
		getDriver().findElement(By.linkText("Contacts")).click();
	}
	
	public MyAccountPage clickOnAccounts() {
		getDriver().findElement(By.linkText("Accounts")).click();
		return new MyAccountPage();
	}
}
