package pages;

import base.ProjectSpecificMethod;

public class MyLeadsPage extends ProjectSpecificMethod {

}
