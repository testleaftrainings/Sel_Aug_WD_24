package testcase;

import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class AccountPage_TC_002 extends ProjectSpecificMethod {
	
	@Test
	public void login() {
		
		//create object for LoginPage
		
		LoginPage lp=new LoginPage();
		
		//method level chaining
		lp.enterUserName("DemoCsr")
		.enterPassWord("crmsfa")
		.clickOnLoginButton()
		.clickOnCrmsfa()
		.clickOnAccounts();
		
	}

}
