package pages;

import base.ProjectSpecificMethod;

public class CreateLeadPage extends ProjectSpecificMethod{

}
