package base;
import org.aeonbits.owner.ConfigCache;
public class Configuartion {

	
	//static method
	
	public static ConfigurationManager configuartion() {
		
		return ConfigCache.getOrCreate(ConfigurationManager.class);
		
	}
}
