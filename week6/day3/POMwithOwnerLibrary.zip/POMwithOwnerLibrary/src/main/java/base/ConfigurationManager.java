package base;

import org.aeonbits.owner.Config;


//set path for properties
@Config.Sources("classpath:config.en.properties")

public interface ConfigurationManager extends Config {
	
	@Key("username")
	String uname();
	
	@Key("password")
	String pass();
	
	@Key("MyHomePage.Leads")
	String clickOnLeads();

}
