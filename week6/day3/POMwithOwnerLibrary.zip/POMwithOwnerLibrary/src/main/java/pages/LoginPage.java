package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.Configuartion;
import base.ProjectSpecificMethod;

public class LoginPage extends ProjectSpecificMethod {
	
	
	public LoginPage(ChromeDriver driver) {
		this.driver=driver;
	}
	
	
	
	public LoginPage enterUserName() {
		
		String uname2 = Configuartion.configuartion().uname();
		driver.findElement(By.id("username")).sendKeys(uname2);
		
		return this;
	}

	public LoginPage enterPassWord() {
		String pass2 = Configuartion.configuartion().pass();
		driver.findElement(By.id("password")).sendKeys(pass2);
		
		return this;
	}
	
	public HomePage clickOnLoginButton() {
		driver.findElement(By.className("decorativeSubmit")).click();

	
		return new HomePage(driver);
		
		
		
	}
}
