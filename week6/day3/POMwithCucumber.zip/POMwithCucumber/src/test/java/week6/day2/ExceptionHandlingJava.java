package week6.day2;

public class ExceptionHandlingJava {

	public static void main(String[] args) {
		int[] value= {23,4,43,12,56,76,33};

		try {
			System.out.println(10/0);

		}catch(ArithmeticException a) {
			System.out.println(a);
			System.out.println(10/5);
		}
		catch (Exception e) {
			System.out.println(e);
		}finally {
			System.out.println("DB Connected");
		}

		System.out.println("Program Successful");

	}

}
