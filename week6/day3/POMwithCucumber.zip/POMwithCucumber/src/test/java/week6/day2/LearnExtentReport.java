package week6.day2;

import java.io.IOException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class LearnExtentReport {

	public static void main(String[] args) throws IOException {

		//set the path of report added
		ExtentHtmlReporter er=new ExtentHtmlReporter("./reports/result.html");
		
		//report should not override
		er.setAppendExisting(true);
		
		//create object for extent report
		ExtentReports ers=new ExtentReports();
		
		
		//connect step 1 and step 2
		ers.attachReporter(er);
		
		//test details 
		ExtentTest test=ers.createTest("Login Page", "Leaftaps Application");
		test.assignAuthor("Dilip");
		test.assignCategory("Smoke");
		
		//set step level status
		test.pass("EnterUserName");
		test.pass("EnterPassword");
		test.pass("Click on login button");
		test.pass("Crmfsa", MediaEntityBuilder.createScreenCaptureFromPath(".././data/img.png").build());
		
		ExtentTest test1=ers.createTest("CreateLead", "Leaftaps Application for CreateLead");
	test1.assignAuthor("Gokul");
	test1.assignCategory("sanity");
	
	test1.pass("crmsfa",MediaEntityBuilder.createScreenCaptureFromPath(".././data/img.png").build());
	test1.fail("leads",MediaEntityBuilder.createScreenCaptureFromPath(".././data/img.png").build());
	
		//close
		ers.flush();
		
		System.out.println("done");
		
	}

}
