package week6.day2;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.NoSuchElementException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;

public class ExceptionHandlingSelenium {

	public static void main(String[] args) throws InterruptedException, IOException {

		ChromeDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.get("http://leaftaps.com/opentaps/control/main");
		try {
			driver.findElement(By.id("Username")).sendKeys("DemoSalesManager");
		} catch (Exception e) {
			driver.findElement(By.id("username")).sendKeys("DemoCSR2");
//throw new NoSuchElementException("Check the value id loactor is present in Dom");
			

		}
		
		try {
			driver.findElement(By.id("password")).sendKeys("crmsfa");
			
			
		} catch (Exception e) {
			System.out.println(e);
		}
		
		
		
		try {
			driver.findElement(By.className("decorativeSubmit")).click();
		} catch (Exception e) {
			System.out.println(e);
		}
		
		Thread.sleep(3000);
		
		File scr = driver.getScreenshotAs(OutputType.FILE);
		File dst=new File("./data/img.png");
		FileUtils.copyFile(scr, dst);
	}

}
