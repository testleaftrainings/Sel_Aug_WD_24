package testcase;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class LoginPage_TC_001 extends ProjectSpecificMethod {
	
	@BeforeTest
	public void setvalue() {
	//	data="LoginPage";
		testName="LoginPage";
		testDescription="LeafTaps Application for Login";
		testAuthor="Dilip";
		testCategory="Smoke";
	}
	
	
	
	
	@Test()
	public void login() throws IOException {
		
		//create object for LoginPage
		
		LoginPage lp=new LoginPage();
		
		System.out.println();
		//method level chaining
		lp.enterUserName()
		.enterPassWord()
		.clickOnLoginButton()
		.clickOnCrmsfa()
		.clickOnLeads();
		
	}

}
