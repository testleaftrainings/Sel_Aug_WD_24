package testcase;

import java.io.IOException;

import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class AccountPage_TC_002 extends ProjectSpecificMethod {
	
	@Test
	public void login() throws IOException {
		
		//create object for LoginPage
		
		LoginPage lp=new LoginPage();
		
		//method level chaining
		lp.enterUserName()
		.enterPassWord()
		.clickOnLoginButton()
		.clickOnCrmsfa()
		.clickOnAccounts();
		
	}

}
