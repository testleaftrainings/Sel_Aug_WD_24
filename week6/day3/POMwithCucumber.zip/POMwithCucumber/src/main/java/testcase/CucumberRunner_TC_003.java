package testcase;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;

import base.ProjectSpecificMethod;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features="src/main/java/features/Login.feature",
glue="pages",
publish=true,
monochrome=true)

public class CucumberRunner_TC_003 extends ProjectSpecificMethod{

	
	   @DataProvider(parallel = true)
	    public Object[][] scenarios() {
	        
		   return super.scenarios();
	    }
	   
	   @BeforeTest
	   public void setValues() {
		   testName="LoginPage1";
			testDescription="LeafTaps Application for Login";
			testAuthor="Dilip";
			testCategory="Smoke";
	   }
}


//super -refer the parent class property