package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginPage extends ProjectSpecificMethod {
	
	

	
	@When("Enter the username as DemoCsr")
	public LoginPage enterUserName() throws IOException {
		try {
			getDriver().findElement(By.id("username")).sendKeys(p.getProperty("userName"));
			reportStep("UserName Enter Successful", "pass");
		} catch (Exception e) {
			reportStep("Username not Enter", "fail");
		}
		
		return this;
	}

	@And("Enter the passWord as crmsfa")
	public LoginPage enterPassWord() throws IOException {
		try {
			getDriver().findElement(By.id("password")).sendKeys(p.getProperty("password"));
			reportStep("Password Enter Successful", "pass");
		} catch (Exception e) {
			reportStep("Password not Enter", "fail");

		}
		
		return this;
	}
	
	@And("Click on Login Button")
	public HomePage clickOnLoginButton() throws IOException {
		try {
			getDriver().findElement(By.className("decorativeSubmit")).click();
			reportStep("Login is Clicked", "pass");
		} catch (Exception e) {
			reportStep("Login is not clicked", "fail");
		}
		return new HomePage();
	}
	
	@Then("Verfiy the login is Successful")
	public void verify() {
		String title = getDriver().getTitle();
		
		if(title.contains("Leaftaps")) {
			System.out.println("Login is successful");
		}else {
			System.out.println("Login is not successful");
		}
	}
}
