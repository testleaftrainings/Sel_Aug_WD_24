package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class MyHomePage extends ProjectSpecificMethod {

	
	
	
	public CreateLeadPage clickOnLeads() throws IOException {
		try {
			getDriver().findElement(By.linkText(p.getProperty("MyHomePage.Leads"))).click();
			reportStep("Leads Button is clicked", "pass");
		} catch (Exception e) {
			reportStep("Leads button is not clicked", "fail");
		}
		
		return new CreateLeadPage();
	}
	
	
	public void clickOnContacts() {
		getDriver().findElement(By.linkText("Contacts")).click();
	}
	
	public MyAccountPage clickOnAccounts() {
		getDriver().findElement(By.linkText("Accounts")).click();
		return new MyAccountPage();
	}
}
