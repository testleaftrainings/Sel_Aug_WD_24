package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class HomePage extends ProjectSpecificMethod {

	
	
	public MyHomePage clickOnCrmsfa() throws IOException {
		try {
			getDriver().findElement(By.linkText("CRM/SFA")).click();
			reportStep("Crmsfa is clicked", "pass");
		} catch (Exception e) {
			
			reportStep("crmsfa is not clicked", "fail");
		}

		return new MyHomePage();
	}
	
	
	public LoginPage clickOnLogOut() throws IOException {
		try {
			getDriver().findElement(By.className("decorativeSubmit")).click();
			
			reportStep("logout is clicked", "pass");
		} catch (Exception e) {
			reportStep("Logout is not clicked", "fail");
		}
		return new LoginPage();

	}
}
