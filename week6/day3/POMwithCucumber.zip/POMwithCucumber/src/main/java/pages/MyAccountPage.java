package pages;

import base.ProjectSpecificMethod;

public class MyAccountPage extends ProjectSpecificMethod {

}
