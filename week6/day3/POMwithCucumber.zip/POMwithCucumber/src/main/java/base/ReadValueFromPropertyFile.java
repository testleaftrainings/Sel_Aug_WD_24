package base;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ReadValueFromPropertyFile {

	public static void main(String[] args) throws IOException {

		//step 1-set path of properties file
		
		FileInputStream f=new FileInputStream("src/main/resources/French.properties");
		
		//step 2 ,create object for properties class
 Properties p=new Properties();
 
 //step 3
 p.load(f);
 
 //read the value from property file
 String property = p.getProperty("MyHomePage.Leads");
 
 System.out.println(property);
	}

}
