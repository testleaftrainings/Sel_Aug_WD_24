 package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.IntegrationWithTC;



public class ProjectSpecificMethod extends AbstractTestNGCucumberTests{


	
	private static final ThreadLocal<RemoteWebDriver> cdDriver=new ThreadLocal<RemoteWebDriver>();
	
	//step2
	public static ExtentReports ers;
	
	public static ExtentTest test ,node;
	
	public String testName,testDescription,testAuthor,testCategory;
	
	public void setDriver() {
		cdDriver.set(new ChromeDriver());
	}
	
	
	public RemoteWebDriver getDriver() {
		return cdDriver.get();
	}
	public static Properties p;
	
	public String data;
	
	
	@BeforeMethod
	public void preCondition() throws IOException {
		
		FileInputStream f=new FileInputStream("src/main/resources/English.properties");
		p=new Properties();
		p.load(f);

		node=test.createNode(testName);
	 setDriver();
	 getDriver().manage().window().maximize();
	 getDriver().get("http://leaftaps.com/opentaps/control/main");
	 getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
	}
	
	
	
	@AfterMethod
	public void postCondition() {
		getDriver().close();
	}
	

	@DataProvider(name="getData",indices = {0})
	public String[][] setValue() throws IOException{
		//excel prg Classname.methodname and return value
		return IntegrationWithTC.readExcel(data);
		
	}
	
	//step1
	@BeforeSuite
	public void startReport() {
		
				ExtentHtmlReporter er=new ExtentHtmlReporter("./reports/result.html");
				er.setAppendExisting(true);
				 ers=new ExtentReports();
				ers.attachReporter(er);
	}
	//step3
	@AfterSuite
	public void stopReport() {
		ers.flush();

	}
	@BeforeClass
	public  void testDetails() {
		test=ers.createTest(testName, testDescription);
		test.assignAuthor(testAuthor);
		test.assignCategory(testCategory);

	}
	
	public void reportStep(String stepDetails,String status) throws IOException {
		if(status.equalsIgnoreCase("Pass")) {
			node.pass(stepDetails, MediaEntityBuilder.createScreenCaptureFromPath(".././snap/image"+takeSnap()+".png").build());
		}else if(status.equalsIgnoreCase("Fail")) {
			node.fail(stepDetails,MediaEntityBuilder.createScreenCaptureFromPath(".././snap/image"+takeSnap()+".png").build());
		}
		
	}
	
	
	
	public int takeSnap() throws IOException {
		int random =(int) (Math.random()*99999);
		File scr = getDriver().getScreenshotAs(OutputType.FILE);
		File dst=new File("./snap/image"+random+".png");
		FileUtils.copyFile(scr, dst);
		
		return random;
		
		
	}
	
}
