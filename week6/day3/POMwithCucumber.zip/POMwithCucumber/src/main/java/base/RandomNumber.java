package base;

public class RandomNumber {

	public static void main(String[] args) {
		int random =(int) (Math.random()*99999);
		System.out.println(random);
		//image3456789.png
		//image8754345.png
	}

}
